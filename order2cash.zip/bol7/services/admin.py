from django.contrib import admin
from .models import Service, Order, OrderItem, Cart

# Customizing the Service model in the admin interface
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'is_active', 'created_at', 'updated_at')
    list_filter = ('category', 'is_active')
    search_fields = ('name', 'description', 'category')
    ordering = ('name',)

    fieldsets = (
        (None, {
            'fields': ('name', 'description', 'price', 'category', 'is_active', 'image')
        }),
        ('Advanced options', {
            'classes': ('collapse',),
            'fields': ('created_at', 'updated_at'),
        }),
    )

    readonly_fields = ('created_at', 'updated_at')

# Register Service model
admin.site.register(Service, ServiceAdmin)

# Customizing the Order model in the admin interface
class OrderAdmin(admin.ModelAdmin):
    list_display = ('customer_name', 'customer_email', 'total_amount', 'order_date', 'status')
    list_filter = ('status',)
    search_fields = ('customer_name', 'customer_email', 'status')
    ordering = ('order_date',)

# Register Order model
admin.site.register(Order, OrderAdmin)

# Customizing the OrderItem model in the admin interface
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'service', 'quantity')
    search_fields = ('order__id', 'service__name')
    list_filter = ('order', 'service')

# Register OrderItem model
admin.site.register(OrderItem, OrderItemAdmin)

# Customizing the Cart model in the admin interface
class CartAdmin(admin.ModelAdmin):
    list_display = ('customer', 'service', 'quantity')
    search_fields = ('customer__username', 'service__name')
    list_filter = ('customer', 'service')

# Register Cart model
admin.site.register(Cart, CartAdmin)
