from django.shortcuts import render, get_object_or_404, redirect
from .models import Service, Cart, Order, OrderItem
from django.http import HttpResponseRedirect

def service_list(request):
    services = Service.objects.filter(is_active=True)
    return render(request, 'services/service_list.html', {'services': services})

def service_detail(request, service_id):
    service = get_object_or_404(Service, id=service_id)
    return render(request, 'services/service_detail.html', {'service': service})

def checkout(request):
    # Get the items in the user's cart
    cart_items = Cart.objects.filter(customer=request.user)

    # Calculate the total price of items in the cart
    total_price = sum(item.get_total() for item in cart_items)

    if request.method == 'POST':
        # Process the checkout form and payment here
        # For now, just redirect to payment (or handle accordingly)
        return redirect('payment')  # Or redirect to a payment method

    return render(request, 'services/checkout.html', {
        'cart_items': cart_items,
        'total_price': total_price,
    })

def add_to_cart(request, service_id):
    # Get the service from the database
    service = get_object_or_404(Service, id=service_id)
    
    # Get the quantity from the POST data (default to 1 if not provided)
    quantity = request.POST.get('quantity', 1)
    try:
        quantity = int(quantity)
        if quantity <= 0:
            quantity = 1  # Ensure quantity is a positive number
    except ValueError:
        quantity = 1  # If it's not a valid integer, default to 1

    # Check if the cart item already exists
    cart_item, created = Cart.objects.get_or_create(customer=request.user, service=service)

    # If the cart item already exists, update its quantity
    if not created:
        cart_item.quantity += quantity
        cart_item.save()

    # Redirect the user to the cart page
    return redirect('cart')  # Redirect to the cart page

def cart(request):
    # Get the items in the user's cart
    cart_items = Cart.objects.filter(customer=request.user)

    # Calculate the total price of items in the cart
    total_price = sum(item.get_total() for item in cart_items)

    # Render the cart page with cart items and total price
    return render(request, 'services/cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
    })

def payment(request):
    # Here you would integrate the payment gateway (Razorpay, Stripe, etc.)
    return render(request, 'services/payment.html')
